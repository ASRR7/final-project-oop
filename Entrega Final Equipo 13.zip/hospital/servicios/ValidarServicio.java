package hospital.servicios;

public class ValidarServicio {
    
}
