package hospital.servicios;


import hospital.object.pacientes.Paciente;
import hospital.state.IPacienteState;
import hospital.state.PacienteEnfermo;
import hospital.state.PacienteMuerto;
import hospital.state.PacienteSano;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class PacienteServicio {
    /**
     * <h1>makePaciente</h1>
     * Tomando como base los parámetros pasados, crea un objeto Paciente con los parámetros dados y lo devuelve
     * @param nombre
     * @param sexo
     * @param edad
     * @param esEmbarazo
     * @param esLactancia
     * @param esGeriatria
     * @param esInfancia
     * @return
     * @throws RuntimeException
     */
    public static Paciente makePaciente(String nombre, String sexo, int edad, boolean esEmbarazo, boolean esLactancia, boolean esGeriatria, boolean esInfancia) throws RuntimeException{
        return new Paciente(nombre, sexo, edad, new PacienteEnfermo(), esEmbarazo, esLactancia, esGeriatria, esInfancia);
    }
    public static ArrayList <Paciente> leerPacienteTxt() throws RuntimeException{
        String fileName = "Pacientes.txt";
        String filePath = "hospital/archivosTXT/" + fileName;
        ArrayList<Paciente> pacientes = new ArrayList<>();
        try {
            
            FileReader fileReader = new FileReader(filePath);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] info = line.split(",");
                String nombre = info[0];
                String sexo = info[1];  
                int edad = Integer.parseInt(info[2]);
                String estado = info[3];
                IPacienteState pacienteEstado = null;
                boolean esEmbarazo = info[4].equals("Si");
                boolean esLactancia = info[5].equals("Si");
                boolean esGeriatria = info[6].equals("Si");
                boolean esInfancia = info[7].equals("Si");
                switch (estado) {
                    case "El paciente esta Enfermo":
                        pacienteEstado = new PacienteEnfermo();
                        break;
                    case "El paciente esta Sano":
                        pacienteEstado = new PacienteSano();
                        break;
                    case "El paciente esta Muerto":
                        pacienteEstado = new PacienteMuerto();
                        break;
                }
                pacientes.add(new Paciente(nombre, sexo, edad, pacienteEstado, esEmbarazo, esLactancia, esGeriatria, esInfancia));
            }
            bufferedReader.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return pacientes;
    }
    /**
     * <h1>writePacienteTxt</h1>
     * Tomando como base un ArrayList de Pacientes, los añade a Pacientes.txt para que puedan ser leidos posteriormente
     * @param Pacientes
     * @throws RuntimeException
     */
    public static void writePacienteTxt(ArrayList<Paciente> Pacientes) throws RuntimeException{
        String fileName = "Pacientes.txt";
        String filePath = "hospital/archivosTXT/" + fileName;
        String comma = ",";
        String lineBreak = "\n";
        try{
        FileWriter myWriter = new FileWriter(filePath);
        for(Paciente paciente: Pacientes){
                    String nombre = paciente.getNombre();
                    String sexo = paciente.getSexo();
                    String edad = Integer.toString(paciente.getEdad());
                    String esEmbarazo = paciente.getEsEmbarazo() ? "Si" : "No";
                    String esLactancia = paciente.getEsLactancia() ? "Si" : "No";
                    String esGeriatria = paciente.getEsGeriatria() ? "Si" : "No";
                    String esInfancia = paciente.getEsInfancia() ? "Si" : "No";
                    String estado = paciente.toString();
                    String pacienteInfo = nombre+comma +
                            sexo +comma +
                            edad + comma +
                            estado + comma +
                            esEmbarazo + comma +
                            esLactancia + comma +
                            esGeriatria + comma +
                            esInfancia + comma +
                            lineBreak;
                    myWriter.write(pacienteInfo);
                }
                myWriter.close();
    
    }catch (IOException e) {
        e.printStackTrace();
    }
    }
    /**
     * <h1>searchByIdPaciente</h1>
     * Busca (por ID) en un ArrayList de Pacientes el objeto Paciente  y lo devuelve
     * En caso de no encontrarlo, devuelve null
     * @param pacientes
     * @param id
     * @return
     */
    public static Paciente searchByIdPaciente(ArrayList<Paciente> pacientes, int id) {
        for (Paciente paciente : pacientes) {
            if (paciente.getId() == id) {
                return paciente;
            }
        }
        return null;
    }
    /**
     * <h1>pacienteExpediente</h1>
     * Busca (por ID) en un ArrayList de Pacientes el objeto Paciente y devuelve el toString() de su expediente
     * En caso de no encontrarlo, devuelve null
     * @param pacientes
     * @param id
     * @return
     */
    public static String pacienteExpediente(ArrayList<Paciente> pacientes, int id) {
        for (Paciente paciente : pacientes) {
            if (paciente.getId() == id) {
                return paciente.getExpediente().toString();
            }
        }
        return null;
    }
    /**
     * <h1>mostrarPacientes</h1>
     * Devuelve un String con el nombre y ID de cada paciente en el ArrayList de pacientes
     * @param pacientes
     * @return String
     * @throws NullPointerException
     */
    public static String mostrarPacientes(ArrayList<Paciente> pacientes) throws NullPointerException{
        String nombreIdPaciente = ("Lista de Pacientes:\n");
        try {
            for (Paciente p : pacientes) {
                nombreIdPaciente += ("Nombre: " + p.getNombre() + "\tID: " + p.getId() + "\n");
            }
        } catch ( NullPointerException e) {
            throw new NullPointerException(e.getMessage());
        }
        return nombreIdPaciente;
    }
}
