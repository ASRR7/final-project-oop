package hospital.servicios;

public class HabitacionServicio {
    
}
