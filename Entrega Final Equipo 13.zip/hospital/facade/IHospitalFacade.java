package hospital.facade;

public interface IHospitalFacade {
    public void cargarDatosIniciales();
    public void cerrarSistema();
}
