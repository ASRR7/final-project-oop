package hospital.object.recursos.Medicamentos;

public class Medicamento {
    protected String nombre;
    private int cantidad; 
    private static int numMedicamentosActual = 0;
    private int id;
    private boolean enEmbarazo;
    private boolean enLactancia;
    private boolean enGeriatria;
    private boolean enInfancia;
    private String EmbarazoString;
    private String LactanciaString;
    private String GeriatriaString;
    private String InfanciaString;

    public Medicamento(String nombre, int cantidad, boolean enEmbarazo, boolean enLactancia, boolean enGeriatria, boolean enInfancia) {
        numMedicamentosActual++;
        this.id = numMedicamentosActual;
        this.nombre = nombre;
        this.cantidad = cantidad;   
        this.enEmbarazo = enEmbarazo;
        this.enLactancia = enLactancia;
        this.enGeriatria = enGeriatria;
        this.enInfancia = enInfancia;
        EmbarazoString = ((enEmbarazo ) ? "Sí" : "No") + " se puede usar en embarazo" ;
        LactanciaString = ((enLactancia) ? "Sí" : "No") +  " se puede usar en lactancia" ;
        GeriatriaString = ((enGeriatria) ? "Sí" : "No") + " se puede usar en geriatría" ;
        InfanciaString = ((enInfancia) ? "Sí" : "No") + " se puede usar en infancia" ;
    }

    public int getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }   
    
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public boolean isEnEmbarazo() {
        return enEmbarazo;
    }

    public void setEnEmbarazo(boolean enEmbarazo) {
        this.enEmbarazo = enEmbarazo;
        EmbarazoString = (enEmbarazo ) ? "Sí se puede usar en embarazo" : "No se puede usar en embarazo";
    }

    public boolean isEnLactancia() {
        return enLactancia;
    }

    public void setEnLactancia(boolean enLactancia) {
        this.enLactancia = enLactancia;
        LactanciaString = (enLactancia) ? "Sí se puede usar en lactancia" : "No se puede usar en lactancia";
    }

    public boolean isEnGeriatria() {
        return enGeriatria;
    }

    public void setEnGeriatria(boolean enGeriatria ) {
        this.enGeriatria = enGeriatria;
        GeriatriaString = (enGeriatria) ? "Sí se puede usar en geriatría" : "No se puede usar en geriatría";
    }

    public boolean isEnInfancia() {
        return enInfancia;
    }

    public void setEnInfancia(boolean enInfancia) {
        InfanciaString = (enInfancia) ? "Sí se puede usar en infancia" : "No se puede usar en infancia";
    }

    public void sintomasSecundarios() {
        System.out.println("Puede causar efectos secundarios comunes.") ;
    }

    public void contraindicaciones() {
        System.out.println("Consultar con un médico antes de usar.");
    }

    public String toString() {
        
        return "\nMedicamento: " + nombre +
                "\n Cantidad: " + cantidad +
                "\n "  + EmbarazoString +
                "\n " + LactanciaString +
                "\n " + GeriatriaString +
                "\n " + InfanciaString;
    }
}
