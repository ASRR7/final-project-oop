package hospital.visitor;

public class IHospitalVisitor {
    
}
